interface Pet 
{
public void test();
}
class Dog implements Pet 
{
public void test()
{
System.out.println("Interface Method Im[plemented");
}
public static void main(String args[])
{
Dog d=new Dog();
d.test();
}
}