class Max
{
   public static void main(String args[])
   {
    int num=70;
    if(num>75)
   {
    System.out.println("Distinction");
    }
   else if(num<75&&num>=60)
   {
   System.out.println("first class");
   }
  else if(num<60&&num>=40)
   {
   System.out.println("pass");
   }
  else
   {
  System.out.println("fail");
  }
 }
}