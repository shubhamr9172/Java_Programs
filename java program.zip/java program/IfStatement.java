class IfStatement
{
   public static void main(String args[])
   {
    int num=10;
    if(num>0)
   {
    System.out.println("number is positive");
    }
   
   System.out.println("this statement is always executed");
   
  
 }
}