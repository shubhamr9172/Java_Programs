class Test3
 {
 public static void main(String s[])
  {
   byte a=4;
   char b='z';
short c=102;
int i=5000;
float f=5.7f;
double d=.124;
double result=(f*a)+(i/b)-(d*c);
System.out.println("result="+result);
}
}