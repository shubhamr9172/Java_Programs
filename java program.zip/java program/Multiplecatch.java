class Multiplecatch
{
 public static void main(String s[])
{
int a,b,c;
try
{
a=Integer.parseInt(s[0]);
b=Integer.parseInt(s[1]);
c=a/b;
System.out.println("division"+c);
}
catch(ArithmeticException ae)
 {
  System.out.println("catch divide by zero");
 }
catch(ArrayIndexOutOfBoundsException ae)
{
System.out.println("Insufficient storage");
}
catch(NumberFormatException ae)
{
System.out.println("Invalid type");
}
}
}