import java.util.*;
class Constructor
{
int a,b;
Constructor()
{
a=10;
b=20;
System.out.println(a +" "+ b);
}
Constructor(int c,int d)
 {
 a=c;
 b=d;
 System.out.println(a +" "+ b);
 }
public static void main(String s[])
{
Constructor c1=new Constructor();
Constructor c2=new Constructor(30,40);
}
}