import java.util.*;
class Sweety
{
 public static void main(String s[])
  {
   String user="plgpl";
   String pass="12345";
   String uid;
   String password;
   Scanner sr=new Scanner(System.in);
   uid=sr.next();
   password=sr.next();
   if(user=="plgpl"&&pass=="12345")
  {
  System.out.println("Hii ! Sir");
  }
else
 {
  System.out.println("Have a good day sir!");
 }
}
}