public class Primitive
  {
   public static void main(String s[])
    {
     Integer a=new Integer(10);
     int b=a.intValue();
      int c=a;
     System.out.println(a+""+b+""+c);
   }
}