 public class SwitchCaseExample1{
  public static void main(String args[])
  {
   int num=2;
     switch(num+2)
      {
       case 1:
         System.out.println("Case1:value is:"+num);
       case 2:
         System.out.println("Case2:value is:"+num);
        case 3:
          System.out.println("Case3:value is:"+num);
        default:
          System.out.println("Default:value is:"+num);
       }
    }
}