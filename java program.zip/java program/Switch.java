import java.util.*;
class Switch
{
 String ch;
 System.out.println("a,e,i,o,u=vowel");
 Scanner sr=new Scanner(System.in);
 ch=sr.nextLine();
 switch(ch)
 {
  case 'A':
  case 'a':
  case 'E':
  case 'e':
  case 'i':
  case 'I':
  case 'O':
  case 'o':System.out.println("vowels");
  break;
  default:System.out.println("consonent");
 
}
}