import java.applet.*;
import java.awt.*;
public class A extends Applet
{
public void paint(Graphics g)
{
g.drawLine(10,20,40,50);
g.setColor(Color.black);
g.drawString("PLGPL",40,45);
s}
}