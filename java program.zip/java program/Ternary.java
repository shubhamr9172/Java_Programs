import java.util.*;
class Ternary
{
public static void main(String s[])
 {
  int a,b;
  Scanner sr=new Scanner(System.in);
  a=sr.nextInt();
  b=sr.nextInt();
  int n=a>b?a:b;
 System.out.println(n);
 }
}