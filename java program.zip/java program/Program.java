public class Program
{
 public static void main(String[]args)
  {
   int value=100;
   switch (value)
   {
    case 100:
    System.out.println(true);
    break;
    case 100:
    System.out.println(true);
    break;
}
}
}