class Demo2
{
    public static void main(String s[])
    {
      System.out.println("Outerclass");
    }
      class nested
      {
      System.out.println("nested");
      }
    

}