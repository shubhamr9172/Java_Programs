class Demo4
{
 public static void main(String s[])
  {
       Vector V1=new Vector();
       Vector V2=new Vector();

 Integer i1=new Integer(10);
 V1.addElement(i1);
 Float f1=new Float(3.14f);
 V1.addElement(f1);
 V1.addElement("java");
 V1.insertElementAt("oop",0);

        for(int i=0;i<v1.size();i++)
          {
            System.out.println(V1.elementAt(i));
          }
      V1.removeElementAt(1);
      System.out.println(V1.size());
      V1.copyInfo(V2);
       V1.removeAllElements();
  
         for(i=0;i<V2.size();i++)
           {
            System.out.println(V2.elementAt(i));
           }
    }
}

