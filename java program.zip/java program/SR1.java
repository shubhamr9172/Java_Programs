import java.util.*;
import java.lang.*;
class SR1
{
public static void main(String s[])
 {
String S1=new String("PLGPL");
int p1=123456;
String Username;
int password;
System.out.println("Enter username");
Scanner sr =new Scanner(System.in);
Username=sr.next();
System.out.println("Enter password");
password=sr.nextInt();
if(S1.equals(Username))
 {
 System.out.println("Hello sir!");
}
else
{
System.out.println("BYE sir!");
}
}
}