import java.applet.*;
import java.awt.*;
class S4 extends Applet
{
public void paint(Graphics g)
 {
   g.drawString("Hello World");
  }
}