import java.util.*;
class Switch1
{
 public static void main(String s[])
 {
char ch;
 System.out.println("a,e,i,o,u=vowel");
 Scanner sr=new Scanner(System.in);
 ch=sr.next().charAt(0);
 switch(ch)
 {
  case 'A':
  case 'a':
  case 'E':
  case 'e':
  case 'i':
  case 'I':
  case 'O':
  case 'o':System.out.println("vowels");
  break;
  default:System.out.println("consonent");
 
}
}
}