class Greater
{
 public static void main(String arg[])
 {
  int a=10;
  if(a>0)
  {
  System.out.println("a is greater");
  }
 else
  {
  System.out.println("a is less than 0");
  }

 }
}