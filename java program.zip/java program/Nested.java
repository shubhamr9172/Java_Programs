class Demo2
{
  System.out.println("Outerclass");
   

class Nested
      {

    public void main(String s[])
      {
      System.out.println("nested");
      }
    
  }
}