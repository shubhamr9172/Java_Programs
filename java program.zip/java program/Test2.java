class Test2
 {
 public static void main(String s[])
 {
 byte b=50;
 b=(byte)(b*2);
 System.out.println(b);
 }
}