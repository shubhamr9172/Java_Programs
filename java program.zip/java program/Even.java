class Even
{
 public static void main(String arg[])
 {
  int a=10;
  if(a%2==0)
  {
  System.out.println("even");
  }
 else
  {
  System.out.println("odd");
  }
 }
}