package pack1;
public class SR5
 {
  public void Display1()
   {
    System.out.println("MOnitoring");
   }
 }