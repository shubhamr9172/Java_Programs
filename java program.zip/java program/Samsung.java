import java.util.*;
import java.lang.*;
class Samsung
{
public static void main(String s[])
 {
  int a;
   Scanner sr=new Scanner(System.in);
   a=sr.nextInt();
    try
      {
       System.out.println(Math.sqrt(a));
      }
     catch(ArithmeticException e)
      {
       System.out.println("ArithmeticException");
       }
    finally
      {
     System.out.println("finally");
      }
  }
}