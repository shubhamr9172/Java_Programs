import java.util.*;
class Demo1
{
public static void main(String s[])
 {
  int f1=-1,f2=1,f3,i;
  System.out.println(f1 +" " + f2);
  
   for(i=0;i<=10;i++)
    {
    f3=f1+f2;
    f1=f2;
    f2=f3;
    System.out.println(f3);
  }
 }
}