class Base
{
void display()
{
 System.out.println("Base");
}
}
class Derived extends Base
{
 void display()
  {
   super.display();
  System.out.println("Derived");
   }
public static void main (String s[])
  {
    Derived b1=new Derived();
    b1.display();
  }
}