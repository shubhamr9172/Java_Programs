import java.util.*;
import java.io.*;
class Equals
{
public static void main(String s[])
{
String s1=new String();
String s2=new String("hello");
Scanner sr=new Scanner(System.in);
s1=sr.next();

if(s1.equals(s2))
  {
    System.out.println("Welcome");
  }
else
  {
 System.out.println("bye bye");
  }
}
}