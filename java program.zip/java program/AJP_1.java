import java.awt.*;
class Demo_1 extends frame
{
      Demo_1()
   {
    Label l1=new Label("This is awt");
    add(l1);
     l1.setBounds(30,40,70,80);
      setTitle("My Frame");
     setVisible(true);
   }
      public static void main(String s[])
        {
         Demo_1 d1=new Demo_1();
          {
          }
}
}