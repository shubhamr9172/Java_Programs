class Result
{
 public static void main(String arg[])
 {
  int marks=70;
  if(marks>=75)
  {
  System.out.println("distinction");
  }
 else if(marks>=60)
  {
  System.out.println("first class");
  }
 else if(marks>=40)
  {
   System.out.println("pass");
  }
 }
}