class Outer
{
int a=10;
void displ()
{
System.out.println(a);
}
void createinner()
{
inner i=new inner();
i.disp2();
}
class inner
{
int b=20;
void disp2()
{
displ();
System.out.println(b);
}
}
}
class inner1
{
public static void main(String s[])
{
Outer o=new Outer();
o.createinner();
}
}