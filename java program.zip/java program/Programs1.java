import.java.util.*;
class Programs1
{
public Static void main(String s[])
{
int a;
Scanner sr=new Scanner(System.in);
a=sr.nextInt();
if(a%2==0)
{
System.out.println("Even");
}
else
{
System.out.println("odd");
}
}
}