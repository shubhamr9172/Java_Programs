import java.applet.*;
import java.awt.*;
class demoApplet extends Applet
{
public void paint(Graphics g)
{
g.drawLine(10,20,40,50);
}
}