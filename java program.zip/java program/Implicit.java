
class Implicit
{
public static void main(String s[])
 {
  float a=12.23f;
  int b=(int)a;
  
 System.out.println(a);
System.out.println(b);
 }
}