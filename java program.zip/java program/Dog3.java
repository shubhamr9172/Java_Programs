interface pet
{
 public void test();
}
class Dog3 implements pet
{
   public void test()
{
System.out.println("Interface Method Implemented");
}
public static void main(String s[]) 
 {
   pet p=new Dog3();
    p.test();
 }
}