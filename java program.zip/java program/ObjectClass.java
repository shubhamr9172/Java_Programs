import java.lang.*;
class ObjectClass
{
   public static void main(String s[])
   {
     String s1="Shubham";
     String s2="Anand";
     String s3="Shubham";
     System.out.println(s1.equals(s2));
     System.out.println(s1.equals(s3));
     System.out.println(s1.getClass());
     System.out.println(s1.hashCode());
     
   }
}