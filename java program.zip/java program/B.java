abstract class A
{
 abstract void show();
}
class B extends A
{
 void show()
  {
   System.out.println("Hello");
  }
public static void main(String s[])
  {
    B b1 =new B();
   b1.show();
  }
}