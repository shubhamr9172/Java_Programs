class Demo1
{
static int a;
}
class StaticDemo
{
public static void main(String s[])
{
Demo1.a=10;
Demo1 d1=new Demo1();
Demo1 d2=new Demo1();
System.out.println(Demo1.a);
System.out.println(d1.a);
System.out.println(d2.a);

}
}