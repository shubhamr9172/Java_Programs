class Test1
{
 public static void main(String args[])
 {
  double d=100.04;
  long L=(long)d;
  int i=(int)L;
  System.out.println("Double value"+d);
  System.out.println("Long value"+L);
  System.out.println("int value"+i);
  }
}
