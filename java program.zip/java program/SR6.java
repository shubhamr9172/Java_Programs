package pack1;
public class SR6
 {
  public void Display2()
  {
   System.out.println("Hello Jarvis");
   }
 }
