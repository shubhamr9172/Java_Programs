
class Test4
{
public static void main(String s[])
 {
  int a[]=new int[5];
  int [] arr=new int[5];
 }
}