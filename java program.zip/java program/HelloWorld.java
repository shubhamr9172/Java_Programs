import java.applet.Applet; 
import java.awt.Graphics; 
  

public class HelloWorld extends Applet  
{ 
    
  
    public void paint(Graphics g)  
    { 
        g.drawString("PLGPL", 200, 200); 
    } 
      
} 